$('html').backstretch([
    "intro.jpg",
    "one.jpg",
    "two.jpg"
], {
    duration: 3000,
    fade: 750
});
