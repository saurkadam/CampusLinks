Session.setDefault('adding_interest', false);
Session.setDefault('updated', null);