CampusLinks
==============
To fix this, we added Iron Router with
meteor add iron:router

Then we moved the main html content into a template named layout
Then we adjusted the router.js file

